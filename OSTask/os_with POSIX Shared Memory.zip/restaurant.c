#include <stdio.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/stat.h>        
#include <fcntl.h>   


#define MAX_TABLES 100
#define MAX_LIMIT 1000


struct Customer
{
 char  customerName [10];
};

struct Table
{
 int tableNo;
 bool available;
 int capacity;
 struct Customer guests[6];
 int noOfGuests;
 int noOfTotalGuests;
 sem_t waitForAll;
};

struct Restaurant
{

 int mealTime;
 struct Table tables[MAX_TABLES];
 int totalTables;
char reminderBook[MAX_LIMIT][6][10];
int noOfGroups;
int noOfPeopleServed;
sem_t closure;
sem_t closeRestaurant;
sem_t eatMeal;
sem_t mutex;
};


int main(int argc,char*argv[])
{
   
   
   
  int shmfd = shm_open ("/srq", O_CREAT | O_EXCL | O_RDWR,S_IRUSR | S_IWUSR);

assert (shmfd != -1);

/* Resize the region to store 1 struct instance */
assert (ftruncate (shmfd, sizeof (struct Restaurant)) != -1);

/* Map the object into memory so file operations aren't needed */
struct Restaurant *restaurant =
  (struct Restaurant*)mmap (NULL, sizeof (struct Restaurant), PROT_READ | PROT_WRITE, MAP_SHARED, shmfd, 0);
assert (restaurant!= MAP_FAILED);


  sem_init(&restaurant->closeRestaurant, 1, 1); //1 means semaphore is used for process synchronization
  sem_init(&restaurant->eatMeal, 1, 0);
  sem_init(&restaurant->mutex,1,1);
  sem_init(&restaurant->closure,1,0);

   restaurant->mealTime=atoi(argv[1]);
   restaurant->totalTables = argc-2;
   for(int i=0;i<restaurant->totalTables;i++)
     {
     restaurant->tables[i].capacity = atoi(argv[i+2]);
     restaurant->tables[i].available = true;
     restaurant->tables[i].tableNo = i;
     }
   restaurant->noOfGroups = 0;
   restaurant->noOfPeopleServed =0;
 

sem_wait(&restaurant->closure);


 for(int i=0;i<restaurant->totalTables;i++)
 { 
   sem_post(&restaurant->tables[i].waitForAll);
 }

 struct timespec ts;

                  if (clock_gettime(CLOCK_REALTIME, &ts) == -1)
                {
                  /* handle error */
                  return -1;
                }

                  ts.tv_sec += restaurant->mealTime/1000;
                  sem_timedwait(&restaurant->eatMeal, &ts);
 
 printf("%d Guests served in %d Groups",restaurant->noOfPeopleServed,restaurant->noOfGroups);

munmap (restaurant, sizeof (struct Restaurant));
close (shmfd);
shm_unlink ("/srq");
}
