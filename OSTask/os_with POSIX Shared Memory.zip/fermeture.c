#include <stdio.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/stat.h>        
#include <fcntl.h> 

#define MAX_TABLES 100
#define MAX_LIMIT 1000

struct Customer
{
 char  customerName [10];
};

struct Table
{
 int tableNo;
 bool available;
 int capacity;
 struct Customer guests[6];
int noOfGuests;
int noOfTotalGuests;
sem_t waitForAll;
};

struct Restaurant
{

 int mealTime;
 struct Table tables[MAX_TABLES];
 int totalTables;
char reminderBook[MAX_LIMIT][6][10];
int noOfGroups;
int noOfPeopleServed;
sem_t closure;
sem_t closeRestaurant;
sem_t eatMeal;
sem_t mutex;
};

int main(int argv,char*argc[])
{


   struct Restaurant *restaurant;

  
int shmfd = shm_open ("/srq", O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
assert (shmfd != -1);
restaurant = (struct Restaurant*)mmap (NULL, sizeof (struct Restaurant), PROT_READ | PROT_WRITE, MAP_SHARED, shmfd, 0);

assert (restaurant!= MAP_FAILED);

 sem_wait(&restaurant->closeRestaurant);
 sem_post(&restaurant->closure);

  munmap (restaurant, sizeof (struct Restaurant));
close (shmfd);
}
